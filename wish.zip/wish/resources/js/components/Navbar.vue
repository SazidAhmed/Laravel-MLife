<template>
    <nav class="navbar navbar-expand-sm navbar-dark bg-info mb-2">
        <div class="container">
            <a href="http://localhost/wish/public/user/dashboard" class="navbar-brand">MLife</a>
        </div>
    </nav>
</template>
