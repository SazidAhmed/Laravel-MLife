

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card text-white bg-info mb-3">
                        <div class="card-body">
                            <div class="container">
                                <awish id="awish"></awish>
                            </div>
                        </div>
                        <div class="card-footer text-white">
                            <div class="row">
                                <div class="col-sm-4">
                                    <p>Developed by :</p>
                                    <p>Sazid Ahmed. <br>
                                    Based on Laravel, Vue & Bootstrap. <br>
                                    copyright@sazid2020
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <p>Visit On:</p>
                                    <p><a href="#" class="text-white">Facebook</a> <br>
                                    <a href="#" class="text-white">Twetter</a> <br>
                                    <a href="#" class="text-white">Instagram</a>
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <p>Contact On: </p>
                                    <p>Email : sazidahmed.official@gmail.com <br>
                                    Mobile: +8801680800810 <br>
                                    Uttara, Dhaka, Bangladesh</p>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wish\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>