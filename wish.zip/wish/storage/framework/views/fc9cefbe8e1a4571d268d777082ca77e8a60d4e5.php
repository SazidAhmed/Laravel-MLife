<!DOCTYPE html>
<html>
<title>TMS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
  html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <span class="w3-bar-item w3-right">TMS</span>
  <!-- <a href="<?php echo e(url('/home/')); ?>" class="btn btn-outline-primary btn-sm">Dashboard</a> -->
</div>

<!-- Sidebar/top-menu -->
<nav class="w3-sidebar w3-collapse w3-teal w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s4">
      <!-- <img src="/w3images/avatar2.png" class="w3-circle w3-margin-right" style="width:46px"> -->
    </div>
    <div class="w3-col s8 w3-bar">
      <span>Welcome, <strong>Sazid</strong></span><br>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i></a>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-user"></i></a>
    </div>
  </div>
  <!--Left Sidebar-->
  <div class="w3-container w3-orange">
    <h5></h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-users fa-fw"></i> Tenant Profile</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-users fa-fw"></i> User Role</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Personal Info</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Family Info</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Emergency Contacts</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Home Maid</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Driver</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-bullseye fa-fw"></i> Landlord</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-teal"><i class="fa fa-dollar fa-fw"></i> Payments</a>
  </div>
</nav>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

<!-- Header Cards-->
  <div class="w3-row-padding w3-margin-bottom">
    <div class="w3-quarter">
      <div class="w3-container w3-red w3-padding-16">
        <div class="w3-left"><i class="fa fa-comment w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>Payment</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Month Name</h4>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-blue w3-padding-16">
        <div class="w3-left"><i class="fa fa-eye w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>99</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Views</h4>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-teal w3-padding-16">
        <div class="w3-left"><i class="fa fa-share-alt w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>23</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Shares</h4>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-orange w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>50</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Users</h4>
      </div>
    </div>
  </div>


<!-- Tanents -->
  <div class="w3-panel">
    <div class="w3-row-padding" style="margin:0 -16px">
      <div class="w3-third">
        <h5>Tanents</h5>
        <table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">
      <tr>
        <td>Floor</td>
        <td>Name</td>
      </tr>
      <tr>
        <td>2nd</td>
        <td>Sazid</td>
      </tr>
    </table><br>
    <button class="w3-button w3-dark-grey">Add Tenant <i class="fa fa-arrow-right"></i></button>
      </div>
<!-- Personal Info -->
      <div class="w3-twothird">
        <h5>Personal Info</h5>
        <table class="w3-table w3-striped w3-white">
          <tr>
            <td><i class="fa fa-user w3-text-blue w3-large"></i></td>
            <td>ID</td>
            <td><i>1</i></td>
          </tr>
          <tr>
            <td><i class="fa fa-bell w3-text-red w3-large"></i></td>
            <td>Floor</td>
            <td><i>2nd</i></td>
          </tr>
          <tr>
            <td><i class="fa fa-bell w3-text-red w3-large"></i></td>
            <td>Name</td>
            <td><i>Sazid</i></td>
          </tr>
        </table>
      </div>
    </div>
  </div>
  <hr>
  <!-- Tenants Details -->
  <div class="w3-container">
    <h5>Tenant's Details</h5>
    <table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">
      <tr>
        <td>F</td>
        <td>1</td>
      </tr>
      <tr>
        <td>N</td>
        <td>2</td>
      </tr>
    </table><br>
    <button class="w3-button w3-dark-grey">Add Details  <i class="fa fa-arrow-right"></i></button>
  </div>
  <hr>
  <!--Payments-->
  <div class="w3-container">
    <h5>Payments</h5>
    <table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">
      <tr>
        <td>F</td>
        <td>1</td>
      </tr>
      <tr>
        <td>N</td>
        <td>2</td>
      </tr>
    </table><br>
    <button class="w3-button w3-dark-grey">Add Payment <i class="fa fa-arrow-right"></i></button>
  </div>
  <hr>
  <!-- recent Comments -->
  <!-- <div class="w3-container">
    <h5>Recent Comments</h5>
    <div class="w3-row">
      <div class="w3-col m2 text-center">
        <img class="w3-circle" src="/w3images/avatar3.png" style="width:96px;height:96px">
      </div>
      <div class="w3-col m10 w3-container">
        <h4>John <span class="w3-opacity w3-medium">Sep 29, 2014, 9:12 PM</span></h4>
        <p>Keep up the GREAT work! I am cheering for you!! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p><br>
      </div>
    </div>

    <div class="w3-row">
      <div class="w3-col m2 text-center">
        <img class="w3-circle" src="/w3images/avatar1.png" style="width:96px;height:96px">
      </div>
      <div class="w3-col m10 w3-container">
        <h4>Bo <span class="w3-opacity w3-medium">Sep 28, 2014, 10:15 PM</span></h4>
        <p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p><br>
      </div>
    </div>
  </div> -->
  <br>
  <!-- Footer Bottom -->
  <div class="w3-container w3-dark-grey w3-padding-32">
    <div class="w3-row">
      <div class="w3-container w3-third">
        <h5 class="w3-bottombar w3-border-green">Demographic</h5>
        <p>Language</p>
        <p>Country</p>
        <p>City</p>
      </div>
      <div class="w3-container w3-third">
        <h5 class="w3-bottombar w3-border-red">System</h5>
        <p>Browser</p>
        <p>OS</p>
        <p>More</p>
      </div>
      <div class="w3-container w3-third">
        <h5 class="w3-bottombar w3-border-orange">Target</h5>
        <p>Users</p>
        <p>Active</p>
        <p>Geo</p>
        <p>Interests</p>
      </div>
    </div>
    <footer class="w3-container">
    <p>Powered by <a href="#" target="_blank">Sazid Ahmed</a></p>
    </footer>
  </div> 
 <!-- End page content -->
</div>

<script>
  // Get the Sidebar
  var mySidebar = document.getElementById("mySidebar");

  // Get the DIV with overlay effect
  var overlayBg = document.getElementById("myOverlay");

  // Toggle between showing and hiding the sidebar, and add overlay effect
  function w3_open() {
    if (mySidebar.style.display === 'block') {
      mySidebar.style.display = 'none';
      overlayBg.style.display = "none";
    } else {
      mySidebar.style.display = 'block';
      overlayBg.style.display = "block";
    }
  }

  // Close the sidebar with the close button
  function w3_close() {
    mySidebar.style.display = "none";
    overlayBg.style.display = "none";
  }
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\tenantbd\resources\views/tenant/dashboard.blade.php ENDPATH**/ ?>