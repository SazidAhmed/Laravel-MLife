<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mywish extends Model
{
    
}
